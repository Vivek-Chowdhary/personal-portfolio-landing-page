# Vivek Chowdhary — Personal Portfolio

A responsive one-page portfolio built with semantic HTML5 and CSS (Flexbox, Grid and media queries).

## Files
- `index.html` — page structure and content
- `style.css` — responsive visual design

## Before publishing
1. Open `index.html` and replace `your.email@example.com`.
2. Replace the GitHub and LinkedIn placeholder URLs with your profile links.
3. Update project descriptions or add repository links when your projects are ready.

## Preview locally
Open the folder in VS Code, install the Live Server extension, then right-click `index.html` and choose **Open with Live Server**.

## Publish free with GitHub Pages
1. Create a public GitHub repository (for example, `vivek-portfolio`).
2. Upload `index.html`, `style.css` and this README to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. After GitHub Pages finishes publishing, your live URL will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/vivek-portfolio/`

## Design decision I'm proud of
The portfolio uses a restrained green-and-cream palette and a strong typographic hero section. The skills and projects use responsive CSS Grid, while Flexbox keeps navigation and smaller groups aligned. This keeps the page readable without sacrificing personality on mobile screens.
